repeat wait() until game:IsLoaded()
warn("Loaded")